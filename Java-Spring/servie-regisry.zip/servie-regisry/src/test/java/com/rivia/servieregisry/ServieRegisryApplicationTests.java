package com.rivia.servieregisry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServieRegisryApplicationTests {

	@Test
	void contextLoads() {
	}

}
